﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZionMarketResearch.Models
{
    public class RedirectRepository
    {
        public static string Redirect(string url)
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                string redirectUrl = null;
                redirectUrl = db.tblredirections.Where(z => z.OldUrl == url && z.IsActive == true).Select(z => z.NewUrl).FirstOrDefault();
                return redirectUrl;
            }
        }
    }
}
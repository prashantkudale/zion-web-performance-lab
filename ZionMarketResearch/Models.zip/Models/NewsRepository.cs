﻿using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;

namespace ZionMarketResearch.Models
{
    public class NewsRepository
    {
        public static List<LatestNewsView> LatestNews()
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                return (from n in db.tblnews
                        where n.IsDeleted == false && n.IsArticle == false && n.IsActive == true
                        orderby n.NewsID descending
                        select new LatestNewsView
                        {
                            NewsId = n.NewsID,
                            NewsTitle = n.NewsTitle,
                            Description = n.News,
                            NewsUrl = n.NewsUrl.ToLower(),
                            PublishedDate = n.PublishedDate.Value
                        }).Take(8).ToList();
            }
        }

        public static NewsDeatils GetNewsByUrl(string url)
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                var news = (from n in db.tblnews
                            where n.NewsUrl == url && n.IsDeleted == false && n.IsActive == true && n.IsArticle == false
                            join r in db.tblreportinformations on n.ReportId equals r.ReportID into leftjoin
                            from subjoin in leftjoin.DefaultIfEmpty()
                            select new NewsDeatils
                            {
                                NewsId = n.NewsID,
                                NewsTitle = n.NewsTitle,
                                Description = n.News,
                                MetaTile = n.MetaTitle,
                                MetaDescription = n.MetaDescription,
                                MetaKeywords = n.MetaKeywords,
                                NewsUrl = n.NewsUrl,
                                PublishedBy = n.PublishedBy,
                                PublishedDate = n.PublishedDate,
                                ReportId = n.ReportId,
                                ReportUrl = subjoin.ReportUrl
                            }).FirstOrDefault();
                if (news != null && news.ReportId != null && news.ReportId > 0)
                {
                    news.Description = EmbedHTML(news.Description, "/custom/" + news.ReportId + "/news",
                    "/buynow/su/" + news.ReportUrl + "/news", "/sample/" + news.ReportUrl + "/news");
                }
                return news;
            }
        }

        public static IPagedList<LatestNewsView> AllNews(int? page)
        {
            zionmysqldbEntities db = new zionmysqldbEntities();
            var allnews = (from n in db.tblnews
                           where n.IsDeleted == false && n.IsArticle == false && n.IsActive == true
                           orderby n.NewsID descending
                           select new LatestNewsView
                           {
                               NewsTitle = n.NewsTitle,
                               Description = n.News,
                               NewsId = n.NewsID,
                               NewsUrl = n.NewsUrl.ToLower(),
                               PublishedDate = n.PublishedDate,
                               PublishedBy = n.PublishedBy
                           }).ToPagedList(page ?? 1, 10);
            return allnews;
        }

        public static List<LatestNewsView> GetAllNews()
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                DateTime preDate = DateTime.Now.AddHours(-24);
                var allnews = (from n in db.tblnews
                               where n.IsDeleted == false && n.IsArticle == false && n.IsActive == true
                               && n.PublishedDate <= preDate
                               orderby n.NewsID descending
                               select new LatestNewsView
                               {
                                   NewsTitle = n.NewsTitle,
                                   Description = n.News,
                                   PublishedDate = n.PublishedDate,
                                   NewsUrl = n.NewsUrl.ToLower()
                               }).ToList();
                return allnews;
            }
        }

        static string EmbedHTML(string newsContent, string customUrl, string buyNowUrl, string requestSampleUrl)
        {
            string html = Util.Utility.ReadTemplate("NewsButton");
            html = html.Replace("[ZMR:BuyNow]", buyNowUrl).
                Replace("[ZMR:RequestSample]", requestSampleUrl).
                Replace("[ZMR:CustomRequest]", customUrl);
            int secondPara = newsContent.IndexOf("</p>", newsContent.IndexOf("</p>") + 5) + 5;
            newsContent = newsContent.Insert(secondPara, "<div class='imgButton'>" + html + "</div>");
            return newsContent;
        }


    }

    public class LatestNewsView
    {
        public int NewsId { get; set; }
        public string NewsTitle { get; set; }
        [UIHint("LatestNewsView")]
        public string Description { get; set; }
        public string NewsUrl { get; set; }
        public DateTime? PublishedDate { get; set; }
        public string PublishedBy { get; set; }
    }

    public class NewsDeatils
    {
        public int NewsId { get; set; }
        public string NewsTitle { get; set; }
        public string NewsUrl { get; set; }
        public string Description { get; set; }
        public string MetaTile { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
        public string PublishedBy { get; set; }
        public DateTime? PublishedDate { get; set; }
        public bool IsArticle { get; set; }
        public int? ReportId { get; set; }
        public string ReportUrl { get; set; }
    }
}
﻿using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZionMarketResearch.Models
{
    public class CategoryRepository
    {
        /// <summary>
        /// This method returns List of parent category with report count
        /// </summary>
        /// <returns></returns>
        public static List<CategoryReportView> GetCategoryWithReportCount()
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {

                var result = db.Zion_GetCategoryWithReportCount();
                var categories = (from c in result
                                  select new CategoryReportView
                                  {
                                      CategoryId = c.CategoryId,
                                      CategoryName = c.CategoryName,
                                      ReportCount = c.ReportCount,
                                      CategoryUrl = "/category/" + c.CategoryUrl
                                  });
                return categories.ToList();
            }
            return null;
        }

        public static List<Category> GetParentCategory()
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                //var categories = (from c in db.tblcategories
                //                  where c.IsDeleted == false && (c.ParentCategoryId == null || c.ParentCategoryId == 0) && db.tblreportinformations.Count(x => x.CategoryBreadCrumb.Contains(System.Data.Objects.SqlClient.SqlFunctions.StringConvert((double)c.pkCategoryID))) > 0
                //                  select new Category
                //                  {
                //                      CategoryId = c.pkCategoryID,
                //                      CategoryName = c.CategoryName,
                //                      CategoryUrl = "/category/" + c.CategoryUrl
                //                  }).ToList();
                //var categories = db.Database.SqlQuery<Category>("SELECT pkCategoryId CategoryId, CategoryName, CONCAT('/category/', CategoryUrl) CategoryUrl FROM tblcategory c WHERE (c.ParentCategoryId is null OR c.ParentCategoryId = 0) AND (SELECT COUNT(*) FROM tblreportinformation WHERE CategoryBreadcrumb like concat('%', c.pkCategoryId, '%')) > 0").ToList();
                var categories = db.Database.SqlQuery<Category>("SELECT pkCategoryId CategoryId, CategoryName, CONCAT('/category/', CategoryUrl) CategoryUrl FROM tblcategory c WHERE (c.ParentCategoryId is null OR c.ParentCategoryId = 0) AND c.IsDeleted = 0").ToList();
                return categories;
            }
        }

        public static List<Category> GetAllCategories()
        {
            using (zionmysqldbEntities db = new zionmysqldbEntities())
            {
                var categories = (from c in db.tblcategories
                                  where c.IsDeleted == false
                                  select new Category
                                  {
                                      CategoryId = c.pkCategoryID,
                                      CategoryName = c.CategoryName,
                                      CategoryUrl = "/category/" + c.CategoryUrl
                                  }).ToList();
                return categories;
            }
        }

        public static CategoryReport GetCategoryWithReports(string categoryUrl, int? page)
        {
            zionmysqldbEntities db = new zionmysqldbEntities();
            CategoryReport cr = new CategoryReport();

            var categorywithreport = (from c in db.tblcategories
                                      where c.CategoryUrl == categoryUrl && c.IsDeleted == false
                                      select c).SingleOrDefault();
            if (categorywithreport != null)
            {
                string str_categoryId = categorywithreport.pkCategoryID.ToString();

                var reports = (from r in db.tblreportinformations
                               where r.CategoryBreadCrumb.Contains(str_categoryId) && r.IsDeleted == false
                               orderby r.ReportID descending
                               select new SearchResultView
                               {
                                   ReportId = r.ReportID,
                                   ReportTitle = r.ReportTitle,
                                   ReportUrl = r.ReportUrl,
                                   SingleUser = r.PriceSingleUser,
                                   PublishedDate = r.PublishDate,
                                   ReportFormat = r.DeliveryFormat,
                                   Description = r.MainPageDescription,
                                   DeliveryFormatClass = r.DeliveryFormat == 0 ? "fa-file-pdf-o iconsize pdf" : r.DeliveryFormat == 1 ? "fa-file-word-o iconsize doc" : r.DeliveryFormat == 2 ? "fa-file-excel-o iconsize xl" : r.DeliveryFormat == 3 ? "fa-file-powerpoint-o iconsize ppt" : "fa-envelope-o iconsize mail",
                                   IsUpcoming = (bool)r.IsUpComing,
                                   NumberOfPages = r.NumberOfPage
                               }).ToPagedList(page ?? 1, 10);
                cr.Category = categorywithreport.CategoryName;
                cr.CategryId = categorywithreport.pkCategoryID;
                cr.Description = categorywithreport.HomePageDescription;
                cr.MetaTitle = categorywithreport.Title;
                cr.MetaDescription = categorywithreport.MetaDescription;
                cr.MetaKeywords = categorywithreport.Keywords;
                cr.CategoryUrl = categorywithreport.CategoryUrl;
                cr.Reports = reports;
                return cr;
            }
            return null;
        }
    }

    public class CategoryReportView
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int ReportCount { get; set; }
        public string CategoryUrl { get; set; }
    }

    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryUrl { get; set; }
    }

    public class CategoryReport
    {
        public int CategryId { get; set; }
        public string Category { get; set; }
        public string MetaTitle { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
        public string Description { get; set; }
        public string CategoryUrl { get; set; }
        public IPagedList<SearchResultView> Reports { get; set; }
    }
}